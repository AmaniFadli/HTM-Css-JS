function processFilm(){
    if((this.readyState == 4) && (this.status == 200)){
        myObj = JSON.parse(this.responseText);
        
        for ( i = 0; i < myObj.data.results.length; i++){

            o1 = document.createElement('div');
            o1.innerHTML = "<img src =" + myObj.data.results[i].thumbnail.path + "." + myObj.data.results[i].thumbnail.extension + " alt = 'imagen' id = 'fotos2' /> " + "<br>"+ myObj.data.results[i].title  ;
            s.appendChild(o1);

           
        }  

        if (page  < 5000){
            page+=100;
            loadFilm();
        } 
    }
}

function loadFilm(){

    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = processFilm;
    
    xmlhttp.open("GET","https://gateway.marvel.com/v1/public/series?ts=1&apikey=35fe75710471f389d484caacf9b4826b&hash=275e2181028ff0bcc30bf19e5d9e8f9d&limit=100&offset=" + page, true);
    xmlhttp.send();

}
function loadEvents(){
    
    page=0;

    s = document.getElementById("listado");
    

    loadFilm();
}