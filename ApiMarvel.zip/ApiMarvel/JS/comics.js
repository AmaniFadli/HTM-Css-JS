// para rellenar el selec y buscar la info de los comics
function loadComics(){
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = processComics;
    xmlhttp.open("GET","https://gateway.marvel.com/v1/public/comics?ts=1&apikey=35fe75710471f389d484caacf9b4826b&hash=275e2181028ff0bcc30bf19e5d9e8f9d&limit=100&offset=" + page, true);
    xmlhttp.send();
}

function processComics(){
    if((this.readyState == 4) && (this.status == 200)){
        myObj= JSON.parse(this.responseText);
        selectComics();
        
    }
}
function selectComics(){

    o1 = document.createElement('option');
    s.appendChild(o1);

    for ( i = 0; i < myObj.data.results.length; i++){
        o1 = document.createElement('option');
        o1.value =  myObj.data.results[i].id;
        o1.innerHTML = myObj.data.results[i].title;
        s.appendChild(o1);
       
    }  
    if (page  < 5000){

        page+=100;
        loadComics();
    } 
}

function loadInfoComics(){

    eleccion = s.value;
    GetInfoComics(eleccion);
}

function GetInfoComics(codigo){

    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = processInfoComics;
    xmlhttp.open("GET","https://gateway.marvel.com/v1/public/comics/"+ codigo + "?ts=1&apikey=35fe75710471f389d484caacf9b4826b&hash=275e2181028ff0bcc30bf19e5d9e8f9d&limit=100&offset=" + page, true);
    xmlhttp.send();
}

function processInfoComics(){
    if((this.readyState == 4) && (this.status == 200)){
        myObj= JSON.parse(this.responseText);

        imagenes.innerHTML  = "<img src =" + myObj.data.results[0].thumbnail.path + "." + myObj.data.results[0].thumbnail.extension + " alt = 'imagen' id = 'fotos' />" ;

        nombre.innerHTML = myObj.data.results[0].title;
    
        texto.innerHTML = myObj.data.results[0].description;
        
    }
}



// para buscar los personajes de los comics
function loadCPers(){

    eleccion2 = s.value;

    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = processCPers;
    xmlhttp.open("GET","https://gateway.marvel.com/v1/public/comics/"+eleccion2+"/characters?ts=1&apikey=35fe75710471f389d484caacf9b4826b&hash=275e2181028ff0bcc30bf19e5d9e8f9d&limit=100", true);
    xmlhttp.send();
}

function processCPers(){
    if((this.readyState == 4) && (this.status == 200)){
        myObj2= JSON.parse(this.responseText);
        selectCPers();
        
    }
}

function selectCPers(){
    
    while(r.length != 0){
        r.remove(0);
    }


    o2 = document.createElement('option');
    o2.value=0;
    o2.innerHTML="CHARACTERS";
    r.appendChild(o2);

    for ( i = 0; i < myObj2.data.results.length; i++){

        o2 = document.createElement('option');
        o2.value = myObj2.data.results[i].id;
        o2.innerHTML = myObj2.data.results[i].name;
        r.appendChild(o2);
        
    } 

}


function processInfoPers(){
    if((this.readyState == 4) && (this.status == 200)){
        myObj3= JSON.parse(this.responseText);
        imagenes.innerHTML  = "<img src =" + myObj3.data.results[0].thumbnail.path + "." + myObj3.data.results[0].thumbnail.extension + " alt = 'imagen' id = 'fotos' />" ;

        nombre.innerHTML = myObj3.data.results[0].name;

        texto.innerHTML = myObj3.data.results[0].description;
        
    }
}



// para buscar la info de los perosnajes de los comics
function loadInfoPers(){
    
    eleccion3 = r.value;
    GetInfoCPers(eleccion3);
}

function GetInfoCPers(codigo2){

    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = processInfoPers;
    xmlhttp.open("GET","https://gateway.marvel.com/v1/public/characters/" + codigo2 + "?ts=1&apikey=35fe75710471f389d484caacf9b4826b&hash=275e2181028ff0bcc30bf19e5d9e8f9d&limit=100&offset=" + page, true);
    xmlhttp.send();
}



function loadEvents(){
    
    page = 0;

    s = document.getElementById("o_comics");
    s.addEventListener('change', loadInfoComics);
    s.addEventListener('change', loadCPers);

    r = document.getElementById("c_personajes");
    r.addEventListener('change', loadInfoPers);

    imagenes = document.getElementById("imagenes");
    texto = document.getElementById("texto");
    nombre = document.getElementById("nombre");
    loadComics();
}
