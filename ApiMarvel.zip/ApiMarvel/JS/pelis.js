function processFilm(){
    if((this.readyState == 4) && (this.status == 200)){
        myObj= JSON.parse(this.responseText);
        selectFilm();
    }
}
function processInfoFilm(){
    if((this.readyState == 4) && (this.status == 200)){
        myObj= JSON.parse(this.responseText);
        
        imagenes.innerHTML  = "<img src =" + myObj.data.results[0].thumbnail.path + "." + myObj.data.results[0].thumbnail.extension + " alt = 'imagen' id = 'fotos' />" ;

        nombre.innerHTML = myObj.data.results[0].title;
    
        texto.innerHTML = myObj.data.results[0].description;
    }
}

function selectFilm(){

    o1 = document.createElement('option');
    s.appendChild(o1);

    for ( i = 0; i < myObj.data.results.length; i++){
        o1 = document.createElement('option');
        o1.value = myObj.data.results[i].id;
        o1.innerHTML = myObj.data.results[i].title;
        s.appendChild(o1);
    }  

    if (page  < 5000){

        page+=100;
        loadFilm();
    } 
    
}

//mirar el codigo de perosnajes de js
function loadInfoFilm(){
    
    eleccion = s.value;
    GetInfoFilm(eleccion);


   
    
}
function GetInfoFilm(codigo){

    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = processInfoFilm;
    
    xmlhttp.open("GET","https://gateway.marvel.com/v1/public/series/"+ codigo +"?ts=1&apikey=35fe75710471f389d484caacf9b4826b&hash=275e2181028ff0bcc30bf19e5d9e8f9d&limit=100&offset=" + page, true);
    xmlhttp.send();

}
function loadFilm(){

    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = processFilm;
    
    xmlhttp.open("GET","https://gateway.marvel.com/v1/public/series?ts=1&apikey=35fe75710471f389d484caacf9b4826b&hash=275e2181028ff0bcc30bf19e5d9e8f9d&limit=100&offset=" + page, true);
    xmlhttp.send();

}
function loadEvents(){
    
    page=0;

    s = document.getElementById("opciones");
    s.addEventListener('change', loadInfoFilm);

    imagenes = document.getElementById("imagenes");
    texto = document.getElementById("texto");
    nombre = document.getElementById("nombre");

    loadFilm();
}