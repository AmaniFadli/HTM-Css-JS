function processPers(){
    if((this.readyState == 4) && (this.status == 200)){
        myObj2 = JSON.parse(this.responseText);
        selectPers();
    }
}

function processInfoPers(){
    if((this.readyState == 4) && (this.status == 200)){
        myObj = JSON.parse(this.responseText);
        
    


        imagenes.innerHTML  = "<img src =" + myObj.data.results[0].thumbnail.path + "." + myObj.data.results[0].thumbnail.extension + " alt = 'imagen' id = 'fotos' />" ;
    
        nombre.innerHTML = myObj.data.results[0].name + " " + " " + " (" + myObj.data.results[0].id + ")";
    
        texto.innerHTML = myObj.data.results[0].description;

    }
}


function selectPers(){

    o2 = document.createElement('option');
    r.appendChild(o2);

   for (j = 0; j < myObj2.data.results.length; j++){
        o2 = document.createElement('option');
        o2.value = myObj2.data.results[j].id;
        o2.innerHTML = myObj2.data.results[j].name;
        r.appendChild(o2);
    } 
  
    if (page  < 1500){
        page += 100;
        loadPers();
    }  
}

function GetPersInfo(codigopers)
{

    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = processInfoPers;
    
    xmlhttp.open("GET","https://gateway.marvel.com/v1/public/characters/" + codigopers + "?ts=1&apikey=35fe75710471f389d484caacf9b4826b&hash=275e2181028ff0bcc30bf19e5d9e8f9d&limit=100&offset=" + page, true);
    xmlhttp.send();
}

function loadinfoPers(){
    
    eleccion = r.value;
    GetPersInfo(eleccion);
   

}
function loadinfoPers2(){
    
    eleccion2 = escrito.value;
    GetPersInfo(eleccion2);

}

function loadPers(){

    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = processPers;
    
    xmlhttp.open("GET","https://gateway.marvel.com/v1/public/characters?ts=1&apikey=35fe75710471f389d484caacf9b4826b&hash=275e2181028ff0bcc30bf19e5d9e8f9d&limit=100&offset=" + page, true);
    xmlhttp.send();
    
}


function loadEvents(){   

    page=0;


    r = document.getElementById("personajes2");
    r.addEventListener('change', loadinfoPers);

    imagenes = document.getElementById("imagenes");
    texto = document.getElementById("texto");
    nombre = document.getElementById("nombre");
    escrito = document.getElementById("escrito");

    b1 = document.getElementById("boton");
    b1.addEventListener('click',loadinfoPers2);

    loadPers();
}   