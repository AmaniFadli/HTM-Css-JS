function processList(){
    if((this.readyState == 4) && (this.status == 200)){
        myObj2 = JSON.parse(this.responseText);
        
        for (j = 0; j < myObj2.data.results.length; j++){
            
            
            o3 = document.createElement('div');
            o3.innerHTML  = "<img src =" + myObj2.data.results[j].thumbnail.path + "." + myObj2.data.results[j].thumbnail.extension + " alt = 'imagen' id = 'fotos2' /> " + "<br>" + myObj2.data.results[j].name + "<hr />";
            r.appendChild(o3);
            
        } 
        if (page  < 1500){
            page += 100;
            loadPers();
        }  
    }
}


function loadPers(){

    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = processList;
    
    xmlhttp.open("GET","https://gateway.marvel.com/v1/public/characters?ts=1&apikey=35fe75710471f389d484caacf9b4826b&hash=275e2181028ff0bcc30bf19e5d9e8f9d&limit=100&offset=" + page, true);
    xmlhttp.send();
    
}

function loadEvents(){   

    page=0;

    r = document.getElementById("listado");
    
    loadPers();
}   