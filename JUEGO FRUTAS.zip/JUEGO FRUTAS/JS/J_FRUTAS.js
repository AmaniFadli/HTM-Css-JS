
function ordenar(){
    // contador de repeticion de las frutas
    auxiliar = new Array(0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
    // contador de repeticion de las imagenes
    otro = new Array(0,0,0,0,0);

    for(n=0;n < 5; n++){
        imagenes[n].src = "IMAGENES/ASPA.png";
    }
   
    j = 0;
    do{
        // i es la  fruta aleatoria
       // console.log(j);
        i = Math.floor(Math.random() * 10);
        //console.log(i);

        if (auxiliar[i] == 0){
            auxiliar[i] = 1;
            auxiliar2[j].innerHTML = frutas[i];

            // imagenes
           z=0;
            do{
                // n es el epsacio de la imagen aleatorio
                n = Math.floor(Math.random() * 5);
 
               if (otro[n] == 0){
                    otro[n] = 1;
                    imagenes[n].src =  "IMAGENES/" + frutas[i] + ".png";
                    imagenes[n].tag = frutas[i];
                    z++;
                } 
            }while( z < 1);

            j++;
        }

    }while (j < 5); 
}

function selectFrut(genObj){
    //otro = new Array(0,0,0,0,0);
    console.log(genObj.target.innerHTML);
    
    nombre1 = genObj.target.innerHTML;
}

function selectImg(genObj){
    console.log(genObj.target.tag);  

    imagen1 = genObj.target.tag;

    if(ganar == false){
        if( nombre1 == imagen1){
            aciertos++; 
            genObj.target.tag = " ";
            genObj.target.src = "IMAGENES/ASPA.png"; 

        }
     
    }
    if (aciertos == 5){
        acabado.innerHTML = "HAS GANADO, POR FAVOR DALE AL BOTON DE REINICIAR ANTES DE VOLVERA JUGAR";
        ganar = true;
    }

    console.log(aciertos);
}

function resetGame(){
    ganar = false;
    aciertos = 0;
    acabado.innerHTML = " ";
    window.addEventListener('load', loadEvents);
}




function loadEvents(){
    b1 = document.getElementById ("b1");
    b2 = document.getElementById("b2");
    text = document.getElementById("frutas");
    m = document.getElementById("mostrar");

    f1 = document.getElementById("fruta1");
    f2 = document.getElementById("fruta2");
    f3 = document.getElementById("fruta3");
    f4 = document.getElementById("fruta4");
    f5 = document.getElementById("fruta5");

    f1.addEventListener('click', selectFrut);
    f2.addEventListener('click', selectFrut);
    f3.addEventListener('click', selectFrut);
    f4.addEventListener('click', selectFrut);
    f5.addEventListener('click', selectFrut);

    im1 = document.getElementById("im1");
    im2 = document.getElementById("im2");
    im3 = document.getElementById("im3");
    im4 = document.getElementById("im4");
    im5 = document.getElementById("im5");

    im1.addEventListener('click', selectImg);
    im2.addEventListener('click', selectImg);
    im3.addEventListener('click', selectImg);
    im4.addEventListener('click', selectImg);
    im5.addEventListener('click', selectImg);

    acabado = document.getElementById("acabado");

    // espacios de las imagenes
    imagenes = new Array (im1, im2, im3, im4, im5);
    // espacios de las frutas
    auxiliar2 = new Array(f1, f2, f3, f4, f5 );
    frutas = new Array("SANDIA", "TOMATE", "MANZANA", "PERA", "PLATANO", "MELOCOTON", "PINYA", "UVA", "KIWI", "MELON");
    //r = "IMAGENES/" + frutas + ".png";
    
    b1.addEventListener('click', resetGame);
    b2.addEventListener('click', ordenar);
    ganar = false;
    aciertos = 0;

}

// genObj.target.id--> se guarda a lo que le e dado 